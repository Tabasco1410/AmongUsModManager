﻿using System;

namespace Among_Us_ModManager.Models
{
    public class NoteItem
    {
        public string Title { get; set; }
        public string Url { get; set; }
        public string Date { get; set; }
    }
}