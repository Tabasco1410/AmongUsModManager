﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Among_Us_ModManager.Models
{
    public static class AppVersion
    {
        public const string Version = "1.3.1";
        public const string ReleaseDate = "2025-07-15";
        public const string Notes = "バグ修正を行いました。Among Us_Modmanagerの名前修正を行いました。";
    }
}
