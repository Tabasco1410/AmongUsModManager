﻿using System;

namespace Among_Us_ModManeger
{
    public class NewsItem
    {
        public DateTime Date { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
